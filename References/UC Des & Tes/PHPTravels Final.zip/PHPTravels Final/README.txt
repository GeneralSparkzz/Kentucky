This includes an entire runthrough of reserving a tour that goes from France to Egypt. Apparently..

Anyways, the test is conducted to ensure the reservation is booked for the day that you would like. I have included all of the information that I think you need to see. If this is not the case and I have missed something, please shoot me an email and I will get you what you need.

For now, thanks for another great quarter!